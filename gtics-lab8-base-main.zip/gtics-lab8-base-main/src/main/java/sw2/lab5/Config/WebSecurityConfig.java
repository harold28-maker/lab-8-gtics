package sw2.lab5.Config;
import org.springframework.context.annotation.*;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import javax.sql.DataSource;
@Configuration @EnableWebSecurity
public class WebSecurityConfig {
 @Bean SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
  http.authorizeRequests().antMatchers("/css/**","/js/**","/webfonts/**","/loginForm","/", "/post").permitAll()
   .antMatchers("/user/list","/user/new","/user/guardar","/user/editar","/user/borrar","/post/borrar").hasAuthority("admin")
   .antMatchers("/user","/user/edit","/post/create","/post/edit","/post/guardar").hasAnyAuthority("admin","user")
   .anyRequest().authenticated()
   .and().formLogin().loginPage("/loginForm").loginProcessingUrl("/processlogin").defaultSuccessUrl("/redirectByRol",true).permitAll()
   .and().logout().logoutUrl("/logout").logoutSuccessUrl("/loginForm?logout").invalidateHttpSession(true).deleteCookies("JSESSIONID").permitAll();
  return http.build();
 }
 @Bean UserDetailsService userDetailsService(DataSource dataSource) {
  JdbcUserDetailsManager manager=new JdbcUserDetailsManager(dataSource);
  manager.setUsersByUsernameQuery("select email,password,active from user where email=?");
  manager.setAuthoritiesByUsernameQuery("select u.email,r.role_name from user u join role r on u.id_role=r.id_role where u.email=? and u.active=1");
  return manager;
 }
 @Bean PasswordEncoder passwordEncoder(){return new BCryptPasswordEncoder();}
}
