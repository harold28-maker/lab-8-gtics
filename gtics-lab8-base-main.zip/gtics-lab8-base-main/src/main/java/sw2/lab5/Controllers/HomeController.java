package sw2.lab5.Controllers;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
@Controller public class HomeController {
 @GetMapping("/") public String home(){return "redirect:/post";}
 @GetMapping("/loginForm") public String login(){return "index";}
}
