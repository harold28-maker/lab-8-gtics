package sw2.lab5.Controllers;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import sw2.lab5.Entity.*;
import sw2.lab5.Repository.*;
import java.util.*;
@Controller @RequestMapping("/user") public class UsuarioController {
 private final UsuarioRepository users;private final PasswordEncoder encoder;
 public UsuarioController(UsuarioRepository users,PasswordEncoder encoder){this.users=users;this.encoder=encoder;}
 @GetMapping("") public String profile(Authentication auth,Model model){model.addAttribute("usuario",users.findByEmail(auth.getName()));return "user/perfil";}
 @GetMapping("/list") public String list(Model model){model.addAttribute("listausuarios",users.findAll());return "user/list";}
 @GetMapping("/new") public String create(Model model){model.addAttribute("usuario",new Usuario());return "user/form";}
 @GetMapping("/editar") public String edit(@RequestParam int id,Model model){model.addAttribute("usuario",users.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND)));return "user/form";}
 @PostMapping("/guardar") public String save(@RequestParam(defaultValue="0") int id_user,@RequestParam String firstname,@RequestParam String lastname,@RequestParam String email,@RequestParam(defaultValue="") String password,@RequestParam(defaultValue="") String intro,@RequestParam(defaultValue="") String profile,@RequestParam(defaultValue="false") boolean active,@RequestParam int roleId){
  Usuario u=id_user==0?new Usuario():users.findById(id_user).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));
  u.setFirstname(firstname);u.setLastname(lastname);u.setEmail(email);u.setIntro(intro);u.setProfile(profile);u.setActive(active);
  if(!password.isBlank())u.setPassword(encoder.encode(password));else if(id_user==0)throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Password required");
  Rol role=new Rol();role.setId_role(roleId);u.setId_role(role);users.save(u);return "redirect:/user/list";}
 @PostMapping("/borrar") public String delete(@RequestParam int id){users.deleteById(id);return "redirect:/user/list";}
}
