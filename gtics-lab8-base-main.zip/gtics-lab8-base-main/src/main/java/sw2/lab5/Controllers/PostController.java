package sw2.lab5.Controllers;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import sw2.lab5.Entity.*;
import sw2.lab5.Repository.*;
@Controller @RequestMapping("/post")
public class PostController {
 private final PostRepository posts; private final UsuarioRepository users;
 public PostController(PostRepository posts,UsuarioRepository users){this.posts=posts;this.users=users;}
 @GetMapping("") public String list(Model model,Authentication auth){model.addAttribute("lista",posts.findAll());model.addAttribute("authEmail",auth==null?"":auth.getName());model.addAttribute("isAdmin",auth!=null&&auth.getAuthorities().stream().anyMatch(a->a.getAuthority().equals("admin")));return "post/lista";}
 @GetMapping("/create") public String create(Model model){model.addAttribute("post",new Post());return "post/form";}
 @GetMapping("/edit") public String edit(@RequestParam int id,Model model,Authentication auth){Post post=posts.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));checkOwner(post,auth);model.addAttribute("post",post);return "post/form";}
 @PostMapping("/guardar") public String save(@ModelAttribute Post incoming,Authentication auth){Post post;
  if(incoming.getId_Post()!=0){post=posts.findById(incoming.getId_Post()).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));checkOwner(post,auth);}else{post=new Post();Usuario user=users.findByEmail(auth.getName());if(user==null)throw new ResponseStatusException(HttpStatus.FORBIDDEN);post.setUser(user);}
  post.setTitle(incoming.getTitle());post.setSummary(incoming.getSummary());post.setContent(incoming.getContent());post.setPublished(incoming.isPublished());posts.save(post);return "redirect:/post";}
 @PostMapping("/borrar") public String delete(@RequestParam int id){posts.deleteById(id);return "redirect:/post";}
 private void checkOwner(Post post,Authentication auth){boolean admin=auth.getAuthorities().stream().anyMatch(a->a.getAuthority().equals("admin"));if(!admin&&!post.getUser().getEmail().equals(auth.getName()))throw new ResponseStatusException(HttpStatus.FORBIDDEN);}
}
